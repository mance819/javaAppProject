<<<<<<< HEAD
import React, { useEffect, useState } from 'react';
=======
import React, { useState } from 'react';
>>>>>>> fd4a6062f64157553bce239213c787a371538c22
import {
  IonContent,
  IonHeader,
  IonPage,
  IonTitle,
  IonToolbar,
  IonButtons,
  IonButton,
  IonIcon,
  IonSearchbar,
  IonItem,
  IonGrid,
  IonRow,
  IonCol,
  IonModal,
  IonInput,
  IonLabel,
  IonItemDivider,
  IonAlert,
} from '@ionic/react';
<<<<<<< HEAD
import { searchOutline, addOutline, trashOutline, createOutline, closeOutline } from 'ionicons/icons';
=======
import { searchOutline, addOutline, createOutline, trashOutline } from 'ionicons/icons';
>>>>>>> fd4a6062f64157553bce239213c787a371538c22
import ExploreContainer from '../components/ExploreContainer';
import './Tab1.css';
import axiosInstance from '../axiosConfig';

interface Department {
  id: string | null;
  code: string;
  name: string;
}

const Tab1: React.FC = () => {
<<<<<<< HEAD
  const [departments, setDepartments] = useState<{  code: string; name: string ;id:string | null;}[]>([
    
  ]);

  const [showModal, setShowModal] = useState(false);
  const [showUpdateModal, setShowUpdateModal] = useState(false);

  const [newDepartment, setNewDepartment] = useState<Department>({  code: '', name: '' ,id: null,});
  const [updateDepartment, setUpdateDepartment] = useState<Department>({  code: '', name: '' ,id: null,});

  const [searchText, setSearchText] = useState('');
  const [deleteIndex, setDeleteIndex] = useState<number | null>(null);
  
  useEffect(() => {
    const fetchDepartments = async () => {
      try {
        const response = await axiosInstance.get('/api/v1/department'); // Adjust the endpoint as needed
        setDepartments(response.data);
      } catch (error) {
        console.error('Error fetching departments:', error);
      }
    };

    fetchDepartments();
  }, []);


=======
  const [departments, setDepartments] = useState<{ name: string; code: string }[]>([
    { name: 'D1', code: 'HR001' },
    { name: 'D2', code: 'FIN002' },
    { name: 'DE', code: 'MKT003' },
  ]);

  const [showModal, setShowModal] = useState(false);
  const [newDepartment, setNewDepartment] = useState({ name: '', code: '' });
  const [searchText, setSearchText] = useState('');
  const [deleteIndex, setDeleteIndex] = useState<number | null>(null);
>>>>>>> fd4a6062f64157553bce239213c787a371538c22

  const filteredDepartments = departments.filter(dept =>
    dept.name.toLowerCase().includes(searchText.toLowerCase())
  );

<<<<<<< HEAD
  const handleDeleteDepartment = async (index: number) => {
    try {
      const departmentToDelete = departments[index];
      await axiosInstance.delete('/api/v1/department', {
        data: { id: departmentToDelete.id }
      });
      const newDepartments = departments.filter((_, i) => i !== index);
      setDepartments(newDepartments);
    } catch (error) {
      console.error('Error deleting department:', error);
    }
=======
  const handleDelete = (index: number) => {
    setDeleteIndex(index);
>>>>>>> fd4a6062f64157553bce239213c787a371538c22
  };

  const handleDeleteConfirmed = () => {
    if (deleteIndex !== null) {
      const updatedDepartments = departments.filter((_, i) => i !== deleteIndex);
      setDepartments(updatedDepartments);
      setDeleteIndex(null); // Reset delete index
    }
  };

<<<<<<< HEAD
 

  const handleUpdateDepartment = async () => {
    try {
      await axiosInstance.post('/api/v1/department', updateDepartment);
      const updatedDepartments = departments.map(dept => 
        dept.id === updateDepartment.id ? updateDepartment : dept
      );
      setDepartments(updatedDepartments);
      setShowUpdateModal(false);
      setUpdateDepartment({ id: null, code: '', name: '' });
    } catch (error) {
      console.error('Error updating department:', error);
    }
  };

  const handleAddDepartment = async () => {
    try {
      setNewDepartment({ ...newDepartment, id:null })
      await axiosInstance.post('/api/v1/department', newDepartment);
      setDepartments([...departments, newDepartment]);
      setShowModal(false);
      setNewDepartment({ id: null, code: '', name: '' });
    } catch (error) {
      console.error('Error adding department:', error);
    }
=======
  const handleEdit = (index: number) => {
    const newName = prompt("Enter new department name:", departments[index].name);
    const newCode = prompt("Enter new department code:", departments[index].code);
    if (newName && newCode) {
      const updatedDepartments = [...departments];
      updatedDepartments[index] = { name: newName, code: newCode };
      setDepartments(updatedDepartments);
    }
  };

  const handleAddDepartment = () => {
    setDepartments([...departments, newDepartment]);
    setNewDepartment({ name: '', code: '' });
    setShowModal(false);
>>>>>>> fd4a6062f64157553bce239213c787a371538c22
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle className="ion-text-color">Tab 1</IonTitle>
          <IonButtons slot="end">
            <IonButton onClick={() => setShowModal(true)}>
              <IonIcon icon={addOutline} />
              <span className="ion-text-color">Add Department</span>
            </IonButton>
          </IonButtons>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen className="tab1-content ion-text-color">
        <IonHeader collapse="condense">
          <IonToolbar>
            <IonTitle size="large" className="ion-text-color">Tab 1</IonTitle>
          </IonToolbar>
        </IonHeader>
        <IonItem>
          <IonSearchbar
            placeholder="Search"
            value={searchText}
            onIonInput={(e: any) => setSearchText(e.target.value)}
            className="ion-text-color"
          ></IonSearchbar>
          <IonButton slot="end">
            <IonIcon icon={searchOutline} />
          </IonButton>
        </IonItem>
        <IonGrid>
          <IonRow>
            <IonCol className="header-blue-background">#</IonCol>
<<<<<<< HEAD
            <IonCol className="header-blue-background">Department Code</IonCol>
=======
>>>>>>> fd4a6062f64157553bce239213c787a371538c22
            <IonCol className="header-blue-background">Department Name</IonCol>
            <IonCol className="header-blue-background">Actions</IonCol>
          </IonRow>
          {filteredDepartments.map((dept, index) => (
            <IonRow key={index}>
<<<<<<< HEAD
              <IonCol>{dept.id}</IonCol>
              <IonCol>{dept.code}</IonCol>
              <IonCol>{dept.name}</IonCol>
              <IonCol>
                <IonButton onClick={() => {
                      setUpdateDepartment(dept);
                      setShowUpdateModal(true);
                    }} fill="clear">
                  <IonIcon icon={createOutline} />
                </IonButton>
                <IonButton onClick={() => handleDeleteDepartment(index)} fill="clear">
=======
              <IonCol>{index + 1}</IonCol>
              <IonCol>{dept.name}</IonCol>
              <IonCol>
                <IonButton onClick={() => handleEdit(index)} fill="clear">
                  <IonIcon icon={createOutline} />
                </IonButton>
                <IonButton onClick={() => handleDelete(index)} fill="clear">
>>>>>>> fd4a6062f64157553bce239213c787a371538c22
                  <IonIcon icon={trashOutline} />
                </IonButton>
              </IonCol>
            </IonRow>
          ))}
        </IonGrid>
        <ExploreContainer name="Tab 1 page" />

        <IonAlert
          isOpen={deleteIndex !== null}
          onDidDismiss={() => setDeleteIndex(null)}
          header={'Confirm Delete'}
          message={'Are you sure you want to delete this department?'}
          buttons={[
            {
              text: 'Cancel',
              role: 'cancel',
              handler: () => {
                setDeleteIndex(null);
              },
            },
            {
              text: 'Delete',
              handler: handleDeleteConfirmed,
            },
          ]}
        />

        <IonModal isOpen={showModal} onDidDismiss={() => setShowModal(false)}>
          <IonHeader>
            <IonToolbar>
              <IonTitle>Add Department</IonTitle>
              <IonButtons slot="end">
                <IonButton onClick={() => setShowModal(false)}>Close</IonButton>
              </IonButtons>
            </IonToolbar>
          </IonHeader>
          <IonContent>
            <IonItem>
              <IonLabel position="stacked">Name</IonLabel>
              <IonInput
                value={newDepartment.name}
                onIonChange={(e) => setNewDepartment({ ...newDepartment, name: e.detail.value! })}
                className="ion-text-color"
              />
            </IonItem>
            <IonItem>
              <IonLabel position="stacked">Code</IonLabel>
              <IonInput
                value={newDepartment.code}
                onIonChange={(e) => setNewDepartment({ ...newDepartment, code: e.detail.value! })}
                className="ion-text-color"
              />
            </IonItem>
            <IonItemDivider />
            <IonButton expand="block" onClick={handleAddDepartment}>
              Add Department
            </IonButton>
          </IonContent>
        </IonModal>
<<<<<<< HEAD

        <IonModal isOpen={showUpdateModal} onDidDismiss={() => setShowUpdateModal(false)}>
          <IonHeader>
            <IonToolbar>
              <IonTitle>Update Department</IonTitle>
              <IonButtons slot="end">
                <IonButton onClick={() => setShowUpdateModal(false)}>
                  <IonIcon slot="icon-only" icon={closeOutline} />
                </IonButton>
              </IonButtons>
            </IonToolbar>
          </IonHeader>
          <IonContent>
            <IonItem>
              <IonLabel position="stacked">ID</IonLabel>
              <IonInput
                value={updateDepartment.id || ''}
                onIonChange={e => setUpdateDepartment({ ...updateDepartment, id: e.detail.value! || null })}
              />
            </IonItem>
            <IonItem>
              <IonLabel position="stacked">Name</IonLabel>
              <IonInput
                value={updateDepartment.name}
                onIonChange={e => setUpdateDepartment({ ...updateDepartment, name: e.detail.value! })}
              />
            </IonItem>
            <IonItem>
              <IonLabel position="stacked">Code</IonLabel>
              <IonInput
                value={updateDepartment.code}
                onIonChange={e => setUpdateDepartment({ ...updateDepartment, code: e.detail.value! })}
              />
            </IonItem>
            <IonButton expand="block" onClick={handleUpdateDepartment}>Update Department</IonButton>
          </IonContent>
        </IonModal>

=======
>>>>>>> fd4a6062f64157553bce239213c787a371538c22
      </IonContent>
    </IonPage>
  );
};

export default Tab1;