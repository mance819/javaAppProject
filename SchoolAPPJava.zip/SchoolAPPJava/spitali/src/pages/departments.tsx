import React, { useState, useEffect } from 'react';
import "./department.css";
import {
  IonContent,
  IonHeader,
  IonPage,
  IonTitle,
  IonToolbar,
  IonButtons,
  IonButton,
  IonModal,
  IonInput,
  IonItem,
  IonList,
  IonText,
} from '@ionic/react';
import { useParams } from 'react-router-dom';
import axios from '../axiosConfig';

interface Department {
  id: string;
  name: string;
  code: string;
}

interface AdmissionState {
  id: string;
  enteringDate: string;
  exitingDate: string;
  cause: string;
  reason: string;
  discharge: boolean;
  patientId: string;
  departmentId: string;
}


const Departments: React.FC = () => {
  const { patientId } = useParams<{ patientId: string }>();
  const [departments, setDepartments] = useState<Department[]>([]);
  const [admitted, setAdmitted] = useState(false);
  const [showAdmitModal, setShowAdmitModal] = useState(false);
  const [showChangeReasonModal, setShowChangeReasonModal] = useState(false);
  const [selectedDepartment, setSelectedDepartment] = useState<string | null>(null);
  const [admissionCause, setAdmissionCause] = useState('');
  const [changeReason, setChangeReason] = useState('');
  const [currentDepartmentId, setCurrentDepartmentId] = useState<string | null>(null);
  const [currentAdmission, setCurrentAdmission] = useState<AdmissionState | null>(null);

  useEffect(() => {

    const fetchDepartments = async () => {
      try {
        const response = await axios.get('/api/v1/department');
        setDepartments(response.data);
      } catch (error) {
        console.error('Error fetching departments:', error);
      }
    };

    const checkAdmissionStatus = async () => {
      try {
        const response = await axios.post(`/api/v1/admission/search`, {
          patientId: patientId 
        });

        if (response.data && response.data.length > 0) {
          const admission = response.data[0]; // Accessing the first object in the array
          setAdmitted(admission.discharge === false);
          setCurrentDepartmentId(admission.departmentId);
          setCurrentAdmission(admission); // Store current admission details
        } else {
          setAdmitted(false);
        }
      } catch (error) {
        console.error('Error checking admission status:', error);
      }
    };

    fetchDepartments();
    checkAdmissionStatus();
  }, [patientId]);

  const handleAdmit = (departmentId: string) => {
    setSelectedDepartment(departmentId);
    setShowAdmitModal(true);
  };

  const handleChangeReason = (departmentId: string) => {
    setSelectedDepartment(departmentId);
    setShowChangeReasonModal(true);
  };

  const submitAdmission = async () => {
    try {
      await axios.post('/api/v1/admission', {
        id: null,
        enteringDate: new Date().toISOString(),
        exitingDate: '',
        cause: admissionCause,
        reason: '',
        discharge: false,
        patientId: parseInt(patientId),
        departmentId: parseInt(selectedDepartment!),
      });
      setShowAdmitModal(false);
      setAdmitted(true);
      setCurrentDepartmentId(selectedDepartment);
    } catch (error) {
      console.error('Error admitting patient:', error);
    }
  };

  const submitChangeReason = async () => {
    try {
      if (currentAdmission) {
        await axios.post('/api/v1/admission', {
          id: currentAdmission.id,
          enteringDate: currentAdmission.enteringDate,
          exitingDate: currentAdmission.exitingDate,
          cause: currentAdmission.cause,
          reason: changeReason,
          discharge: currentAdmission.discharge,
          patientId: currentAdmission.patientId,
          departmentId: selectedDepartment ? parseInt(selectedDepartment) : currentAdmission.departmentId,
        });
        setShowChangeReasonModal(false);
        setCurrentDepartmentId(selectedDepartment);
      }
    } catch (error) {
      console.error('Error changing reason and department:', error);
    }
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Departments</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent>
        <IonList>
          {departments.length === 0 ? (
            <IonItem>
              <IonText>No departments available.</IonText>
            </IonItem>
          ) : (
            departments.map((department) => (
              <IonItem key={department.id}>
                <IonText className='iontexti'>{department.name}</IonText>
                <IonText slot='start'>{department.code}</IonText>
                <IonButtons slot="end">
                  {admitted ? (
                    <IonButton
                      disabled={currentDepartmentId === department.id}
                      onClick={() => handleChangeReason(department.id)}
                    >
                      {currentDepartmentId === department.id ? 'Current Department' : 'Change Department'}
                    </IonButton>
                  ) : (
                    <IonButton onClick={() => handleAdmit(department.id)}>Admit</IonButton>
                  )}
                </IonButtons>
              </IonItem>
            ))
          )}
        </IonList>

        {/* Modal for Admission Cause */}
        <IonModal isOpen={showAdmitModal} onDidDismiss={() => setShowAdmitModal(false)}>
          <IonHeader>
            <IonToolbar>
              <IonTitle>Admission Cause</IonTitle>
            </IonToolbar>
          </IonHeader>
          <IonContent>
            <IonItem>
              <IonInput
                placeholder='cause'
                value={admissionCause}
                onIonChange={(e) => setAdmissionCause(e.detail.value!)}
              />
            </IonItem>
            <IonButton expand="block" onClick={submitAdmission}>
              Submit
            </IonButton>
          </IonContent>
        </IonModal>

        {/* Modal for Changing Reason */}
        <IonModal isOpen={showChangeReasonModal} onDidDismiss={() => setShowChangeReasonModal(false)}>
          <IonHeader>
            <IonToolbar>
              <IonTitle>Change Reason</IonTitle>
            </IonToolbar>
          </IonHeader>
          <IonContent>
            <IonItem>
              <IonInput
                placeholder='reason'
                value={changeReason}
                onIonChange={(e) => setChangeReason(e.detail.value!)}
              />
            </IonItem>
            <IonButton expand="block" onClick={submitChangeReason}>
              Submit
            </IonButton>
          </IonContent>
        </IonModal>
      </IonContent>
    </IonPage>
  );
};

export default Departments;
