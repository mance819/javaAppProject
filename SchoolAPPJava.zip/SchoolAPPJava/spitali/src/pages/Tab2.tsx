<<<<<<< HEAD
import React, { useState, useEffect } from 'react';
=======
import React, { useState } from 'react';
>>>>>>> fd4a6062f64157553bce239213c787a371538c22
import {
  IonContent,
  IonHeader,
  IonPage,
  IonTitle,
  IonToolbar,
  IonButtons,
  IonButton,
  IonIcon,
  IonSearchbar,
  IonItem,
  IonGrid,
  IonRow,
  IonCol,
  IonModal,
  IonInput,
  IonLabel,
  IonItemDivider,
  IonAlert,
  IonText,
<<<<<<< HEAD
  IonRouterLink,
  IonSelect,
  IonSelectOption,
=======
>>>>>>> fd4a6062f64157553bce239213c787a371538c22
} from '@ionic/react';
import {
  searchOutline,
  addOutline,
  createOutline,
  trashOutline,
  closeOutline,
<<<<<<< HEAD
  arrowForwardCircleOutline,
  documentTextOutline,
  closeCircleOutline,
} from 'ionicons/icons';
import axios from '../axiosConfig';
import { useHistory } from 'react-router-dom';
import './Tab2.css';

interface Patient {
  id: string;
  name: string;
  lastName: string;
  birthDate: string;
  status: string;
}

interface ClinicalRecord {
  id: string;
  clinicalRecord: string;
  patientId: string;
}
interface AdmissionState {
  id: string;
  enteringDate: string;
  exitingDate: string;
  cause: string;
  reason: string;
  discharge: boolean;
  patientId: string;
  departmentId: string;
}

const Tab2: React.FC = () => {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [clinicalRecords, setClinicalRecords] = useState<ClinicalRecord[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [showAddPatientModal, setShowAddPatientModal] = useState(false);
  const [showUpdatePatientModal, setShowUpdatePatientModal] = useState(false);
  const [showAddClinicalRecordModal, setShowAddClinicalRecordModal] = useState(false);
  const [showDischargeModal, setShowDischargeModal] = useState(false);
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [deleteIndex, setDeleteIndex] = useState<number | null>(null);
  const [searchText, setSearchText] = useState('');
  const [newPatient, setNewPatient] = useState({ name: '', lastName: '', birthDate: '' });
  const [updatedPatient, setUpdatedPatient] = useState({ id: '', name: '', lastName: '', birthDate: '' });
  const [newClinicalRecord, setNewClinicalRecord] = useState({ id: null, clinicalRecord: '', patientId: '' });
  const [currentAdmission, setCurrentAdmission] = useState<AdmissionState | null>(null);
  const [dischargeReason, setDischargeReason] = useState<string>('');

  const history = useHistory();

  const checkAdmissionStatus = async (patientId: string) => {
    try {
      const response = await axios.post(`/api/v1/admission/search`, {
        patientId: patientId 
      });

      if (response.data && response.data.length > 0) {
        const admission = response.data[0]; // Accessing the first object in the array
        setCurrentAdmission(admission); // Store current admission details
        return admission.discharge === false ? 'Admitted' : 'NotAdmitted';
      } else {
        return 'NotAdmitted';
      }
    } catch (error) {
      console.error('Error checking admission status:', error);
      return 'NotAdmitted';
    }
  };

  useEffect(() => {
    const fetchPatients = async () => {
      try {
        const response = await axios.get('/api/v1/patient'); // Adjust the endpoint as needed
        const patientsWithStatus = await Promise.all(response.data.map(async (patient: Patient) => {
          const status = await checkAdmissionStatus(patient.id);
          return { ...patient, status };
        }));
        setPatients(patientsWithStatus);
      } catch (error) {
        console.error('Error fetching patients:', error);
      }
    };

    fetchPatients();
  }, []);

  const fetchClinicalRecords = async (patientId: string) => {
    try {
      const response = await axios.post('api/v1/clinicaldata/search', {
        data: '',
        patId: parseInt(patientId),
      });
      setClinicalRecords(response.data);
    } catch (error) {
      console.error('Error fetching clinical records:', error);
    }
  };

  const addPatient = async () => {
    try {
      const response = await axios.post('/api/v1/patient', newPatient); // Adjust the endpoint as needed
      const status = await checkAdmissionStatus(response.data.id);
      setPatients([...patients, { ...response.data, status }]);
      setShowAddPatientModal(false);
      setNewPatient({ name: '', lastName: '', birthDate: '' });
    } catch (error) {
      console.error('Error adding patient:', error);
    }
  };

  const updatePatient = async () => {
    try {
      const response = await axios.post(`/api/v1/patient`, updatedPatient); // Adjust the endpoint as needed
      const updatedPatients = patients.map(patient =>
        patient.id === updatedPatient.id ? response.data : patient
      );
      setPatients(updatedPatients);
      setShowUpdatePatientModal(false);
      setUpdatedPatient({ id: '', name: '', lastName: '', birthDate: '' });
    } catch (error) {
      console.error('Error updating patient:', error);
    }
  };

  const addClinicalRecord = async () => {
    try {
      if (selectedPatient) {
        const response = await axios.post('/api/v1/clinicaldata', { ...newClinicalRecord, patientId: selectedPatient.id});
        setClinicalRecords([...clinicalRecords, response.data]);
        setShowAddClinicalRecordModal(false);
        setNewClinicalRecord({id:null, clinicalRecord: '', patientId: '' });
      }
    } catch (error) {
      console.error('Error adding clinical record:', error);
    }
  };

  const dischargePatient = async () => {
    if (!currentAdmission || !selectedPatient) return;

    try {
      const updatedAdmission = {
        id: currentAdmission.id,
        enteringDate: currentAdmission.enteringDate,
        exitingDate: new Date().toISOString(),
        cause: currentAdmission.cause,
        reason: dischargeReason,
        discharge: true,
        patientId: currentAdmission.patientId,
        departmentId: currentAdmission.departmentId,
      };

      await axios.post(`/api/v1/admission`, updatedAdmission);

      const updatedPatients = patients.map(patient =>
        patient.id === selectedPatient.id ? { ...patient, status: 'Discharged' } : patient
      );

      setPatients(updatedPatients);
      setShowDischargeModal(false);
      setCurrentAdmission(null);
      setSelectedPatient(null);
      setDischargeReason('');
    } catch (error) {
      console.error('Error discharging patient:', error);
    }
  };

  const filteredPatients = patients.filter(
    (patient) =>
      patient.name.toLowerCase().includes(searchText.toLowerCase()) ||
      patient.id.toLowerCase().includes(searchText.toLowerCase())
=======
  arrowForwardOutline,
  documentTextOutline,
  closeCircleOutline,
  arrowForwardCircleOutline,
} from 'ionicons/icons';
import './Tab2.css';

interface Patient {
  name: string;
  id: string;
  status: string;
  clinicalRecords: string[];
}

const Tab2: React.FC = () => {
  const [patients, setPatients] = useState<Patient[]>([
    { name: 'John Doe', id: 'P001', status: 'Admitted', clinicalRecords: ['Initial checkup', 'Follow-up X-ray'] },
    { name: 'Jane Smith', id: 'P002', status: 'Admitted', clinicalRecords: ['Blood test', 'MRI scan'] },
    { name: 'Michael Johnson', id: 'P003', status: 'Admitted', clinicalRecords: ['Physical therapy session'] },
  ]);

  const [showModal, setShowModal] = useState(false);
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [deleteIndex, setDeleteIndex] = useState<number | null>(null);

  const [searchText, setSearchText] = useState('');

  const filteredPatients = patients.filter(patient =>
    patient.name.toLowerCase().includes(searchText.toLowerCase()) ||
    patient.id.toLowerCase().includes(searchText.toLowerCase())
>>>>>>> fd4a6062f64157553bce239213c787a371538c22
  );

  const handleDelete = (index: number) => {
    setDeleteIndex(index);
  };

  const handleDeleteConfirmed = () => {
    if (deleteIndex !== null) {
      const updatedPatients = patients.filter((_, i) => i !== deleteIndex);
      setPatients(updatedPatients);
      setDeleteIndex(null); // Reset delete index
    }
  };

  const handleEdit = (index: number) => {
<<<<<<< HEAD
    const patient = patients[index];
    setUpdatedPatient(patient);
    setShowUpdatePatientModal(true);
  };

  const openDischargeModal = async (index: number) => {
    const patient = patients[index];
    setSelectedPatient(patient);
    const status = await checkAdmissionStatus(patient.id);
    setShowDischargeModal(true);
  };

  const openClinicalRecords = async (index: number) => {
    const patient = patients[index];
    setSelectedPatient(patient);
    await fetchClinicalRecords(patient.id);
=======
    const newName = prompt("Enter new patient name:", patients[index].name);
    if (newName) {
      const updatedPatients = [...patients];
      updatedPatients[index] = { ...patients[index], name: newName };
      setPatients(updatedPatients);
    }
  };

  const handleDischarge = (index: number) => {
    const updatedPatients = [...patients];
    updatedPatients[index] = { ...patients[index], status: 'Discharged' };
    setPatients(updatedPatients);
  };

  const openClinicalRecords = (index: number) => {
    setSelectedPatient(patients[index]);
>>>>>>> fd4a6062f64157553bce239213c787a371538c22
    setShowModal(true);
  };

  const handleNext = (index: number) => {
<<<<<<< HEAD
    const patient = patients[index];
    history.push(`/departments/${patient.id}`);
=======
    alert(`Proceed to next action for ${patients[index].name}`);
    // Add logic for next action
>>>>>>> fd4a6062f64157553bce239213c787a371538c22
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
<<<<<<< HEAD
          <IonTitle>Patients</IonTitle>
          <IonButtons slot="end">
            <IonButton onClick={() => setShowAddPatientModal(true)}>
=======
          <IonTitle>Tab 2</IonTitle>
          <IonButtons slot="end">
            <IonButton onClick={() => setShowModal(true)}>
>>>>>>> fd4a6062f64157553bce239213c787a371538c22
              <IonIcon icon={addOutline} />
              Add Patient
            </IonButton>
          </IonButtons>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen className="tab2-content">
        <IonHeader collapse="condense">
          <IonToolbar>
            <IonTitle size="large">Patients</IonTitle>
          </IonToolbar>
        </IonHeader>
        <IonItem>
          <IonSearchbar
            placeholder="Search"
            value={searchText}
            onIonInput={(e: any) => setSearchText(e.target.value)}
          ></IonSearchbar>
          <IonButton slot="end">
            <IonIcon icon={searchOutline} />
          </IonButton>
        </IonItem>
        <IonGrid>
          <IonRow>
<<<<<<< HEAD
            <IonCol>ID</IonCol>
            <IonCol>Name</IonCol>
            <IonCol>Birthdate</IonCol>
=======
            <IonCol>#</IonCol>
            <IonCol>Name</IonCol>
            <IonCol>ID</IonCol>
>>>>>>> fd4a6062f64157553bce239213c787a371538c22
            <IonCol>Status</IonCol>
            <IonCol>Actions</IonCol>
          </IonRow>
          {filteredPatients.map((patient, index) => (
            <IonRow key={index}>
<<<<<<< HEAD
              <IonCol>{patient.id}</IonCol>
              <IonCol>
                {patient.name} {patient.lastName}
              </IonCol>
              <IonCol>{patient.birthDate}</IonCol>
=======
              <IonCol>{index + 1}</IonCol>
              <IonCol>{patient.name}</IonCol>
              <IonCol>{patient.id}</IonCol>
>>>>>>> fd4a6062f64157553bce239213c787a371538c22
              <IonCol>{patient.status}</IonCol>
              <IonCol>
                <IonButton onClick={() => handleEdit(index)} fill="clear">
                  <IonIcon icon={createOutline} />
                </IonButton>
                <IonButton onClick={() => handleDelete(index)} fill="clear">
                  <IonIcon icon={trashOutline} />
                </IonButton>
<<<<<<< HEAD
                <IonButton onClick={() => openDischargeModal(index)} fill="clear">
=======
                <IonButton onClick={() => handleDischarge(index)} fill="clear">
>>>>>>> fd4a6062f64157553bce239213c787a371538c22
                  <IonIcon icon={closeCircleOutline} />
                </IonButton>
                <IonButton onClick={() => handleNext(index)} fill="clear">
                  <IonIcon icon={arrowForwardCircleOutline} />
                </IonButton>
                <IonButton onClick={() => openClinicalRecords(index)} fill="clear">
                  <IonIcon icon={documentTextOutline} />
                </IonButton>
              </IonCol>
            </IonRow>
          ))}
        </IonGrid>

        {/* Modal for Clinical Records */}
        <IonModal isOpen={showModal} onDidDismiss={() => setShowModal(false)}>
          <IonHeader>
            <IonToolbar>
              <IonTitle>Clinical Records</IonTitle>
              <IonButtons slot="end">
                <IonButton onClick={() => setShowModal(false)}>
                  <IonIcon icon={closeOutline} slot="icon-only" />
                </IonButton>
              </IonButtons>
            </IonToolbar>
          </IonHeader>
          <IonContent>
            {selectedPatient && (
              <IonGrid>
                <IonRow>
                  <IonCol>
                    <IonItemDivider>Name:</IonItemDivider>
                    <IonText>{selectedPatient.name}</IonText>
                  </IonCol>
                  <IonCol>
                    <IonItemDivider>ID:</IonItemDivider>
                    <IonText>{selectedPatient.id}</IonText>
                  </IonCol>
                </IonRow>
                <IonRow>
                  <IonCol>
                    <IonItemDivider>Status:</IonItemDivider>
                    <IonText>{selectedPatient.status}</IonText>
                  </IonCol>
                </IonRow>
                <IonRow>
                  <IonCol>
                    <IonItemDivider>Clinical Records:</IonItemDivider>
<<<<<<< HEAD
                    {clinicalRecords.map((record, index) => (
                      <IonItem key={index}>
                        <IonText>{record.clinicalRecord}</IonText>
=======
                    {selectedPatient.clinicalRecords.map((record, index) => (
                      <IonItem key={index}>
                        <IonText>{record}</IonText>
>>>>>>> fd4a6062f64157553bce239213c787a371538c22
                      </IonItem>
                    ))}
                  </IonCol>
                </IonRow>
<<<<<<< HEAD
                <IonRow>
                  <IonCol>
                    <IonButton expand="block" onClick={() => setShowAddClinicalRecordModal(true)}>
                      <IonIcon icon={addOutline} />
                      Add Clinical Record
                    </IonButton>
                  </IonCol>
                </IonRow>
=======
>>>>>>> fd4a6062f64157553bce239213c787a371538c22
              </IonGrid>
            )}
          </IonContent>
        </IonModal>

<<<<<<< HEAD
        {/* Modal for Adding Clinical Records */}
        <IonModal isOpen={showAddClinicalRecordModal} onDidDismiss={() => setShowAddClinicalRecordModal(false)}>
          <IonHeader>
            <IonToolbar>
              <IonTitle>Add Clinical Record</IonTitle>
              <IonButtons slot="end">
                <IonButton onClick={() => setShowAddClinicalRecordModal(false)}>
                  <IonIcon icon={closeOutline} slot="icon-only" />
                </IonButton>
              </IonButtons>
            </IonToolbar>
          </IonHeader>
          <IonContent>
            <IonItem>
              <IonInput
                placeholder="Clinical Record"
                value={newClinicalRecord.clinicalRecord}
                onIonChange={(e) => setNewClinicalRecord({ ...newClinicalRecord, clinicalRecord: e.detail.value! })}
              />
            </IonItem>
            <IonButton expand="block" onClick={addClinicalRecord}>
              Add Clinical Record
            </IonButton>
          </IonContent>
        </IonModal>

        {/* Modal for Adding Patient */}
        <IonModal isOpen={showAddPatientModal} onDidDismiss={() => setShowAddPatientModal(false)}>
          <IonHeader>
            <IonToolbar>
              <IonTitle>Add Patient</IonTitle>
              <IonButtons slot="end">
                <IonButton onClick={() => setShowAddPatientModal(false)}>
                  <IonIcon icon={closeOutline} slot="icon-only" />
                </IonButton>
              </IonButtons>
            </IonToolbar>
          </IonHeader>
          <IonContent>
            <IonItem>
              <IonInput
                placeholder="Name"
                value={newPatient.name}
                onIonChange={(e) => setNewPatient({ ...newPatient, name: e.detail.value! })}
              />
            </IonItem>
            <IonItem>
              <IonInput
                placeholder="Last Name"
                value={newPatient.lastName}
                onIonChange={(e) => setNewPatient({ ...newPatient, lastName: e.detail.value! })}
              />
            </IonItem>
            <IonItem>
              <IonInput
                placeholder="Birthdate"
                value={newPatient.birthDate}
                onIonChange={(e) => setNewPatient({ ...newPatient, birthDate: e.detail.value! })}
              />
            </IonItem>
            <IonButton expand="block" onClick={addPatient}>
              Add Patient
            </IonButton>
          </IonContent>
        </IonModal>

        {/* Modal for Updating Patient */}
        <IonModal isOpen={showUpdatePatientModal} onDidDismiss={() => setShowUpdatePatientModal(false)}>
          <IonHeader>
            <IonToolbar>
              <IonTitle>Update Patient</IonTitle>
              <IonButtons slot="end">
                <IonButton onClick={() => setShowUpdatePatientModal(false)}>
                  <IonIcon icon={closeOutline} slot="icon-only" />
                </IonButton>
              </IonButtons>
            </IonToolbar>
          </IonHeader>
          <IonContent>
            <IonItem>
              <IonInput
                value={updatedPatient.id}
                disabled
                onIonChange={(e) => setUpdatedPatient({ ...updatedPatient, id: e.detail.value! })}
              />
            </IonItem>
            <IonItem>
              <IonInput
                value={updatedPatient.name}
                onIonChange={(e) => setUpdatedPatient({ ...updatedPatient, name: e.detail.value! })}
              />
            </IonItem>
            <IonItem>
              <IonInput
                value={updatedPatient.lastName}
                onIonChange={(e) => setUpdatedPatient({ ...updatedPatient, lastName: e.detail.value! })}
              />
            </IonItem>
            <IonItem>
              <IonInput
                value={updatedPatient.birthDate}
                onIonChange={(e) => setUpdatedPatient({ ...updatedPatient, birthDate: e.detail.value! })}
              />
            </IonItem>
            <IonButton expand="block" onClick={updatePatient}>
              Update Patient
            </IonButton>
          </IonContent>
        </IonModal>

        {/* Modal for Discharging Patient */}
        <IonModal isOpen={showDischargeModal} onDidDismiss={() => setShowDischargeModal(false)}>
          <IonHeader>
            <IonToolbar>
              <IonTitle>Discharge Patient</IonTitle>
              <IonButtons slot="end">
                <IonButton onClick={() => setShowDischargeModal(false)}>
                  <IonIcon icon={closeOutline} slot="icon-only" />
                </IonButton>
              </IonButtons>
            </IonToolbar>
          </IonHeader>
          <IonContent>
            <IonItem>
              <IonLabel>Discharge Reason</IonLabel>
              <IonSelect value={dischargeReason} placeholder="Select One" onIonChange={e => setDischargeReason(e.detail.value)}>
                <IonSelectOption value="Healed">Healed</IonSelectOption>
                <IonSelectOption value="Death">Death</IonSelectOption>
                <IonSelectOption value="Transfer">Transfer</IonSelectOption>
              </IonSelect>
            </IonItem>
            <IonButton expand="block" onClick={dischargePatient}>
              Done
            </IonButton>
          </IonContent>
        </IonModal>

=======
>>>>>>> fd4a6062f64157553bce239213c787a371538c22
        {/* Confirmation Alert for Delete */}
        <IonAlert
          isOpen={deleteIndex !== null}
          onDidDismiss={() => setDeleteIndex(null)}
          header={'Confirm Delete'}
          message={'Are you sure you want to delete this patient?'}
          buttons={[
            {
              text: 'Cancel',
              role: 'cancel',
              handler: () => {
                setDeleteIndex(null);
              },
            },
            {
              text: 'Delete',
              handler: handleDeleteConfirmed,
            },
          ]}
        />
      </IonContent>
    </IonPage>
  );
};

export default Tab2;
