package com.example.projectapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.SearchView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

import models.PatSearchDTO;
import models.PatientModel;
import models.PatientsAdapter;
import retrofit.PatientApi;
import retrofit.RetrofitService;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Patients extends AppCompatActivity {
    private RecyclerView recyclerView;
    private PatientsAdapter adapter;
    private PatientApi api;
    private SearchView searchView;
    Button back;
    Button add;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patients);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        api = RetrofitService.getRetrofitInstance().create(PatientApi.class);

        searchView = findViewById(R.id.searchView);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                performSearch(query);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });

        fetchPatients();

        add = findViewById(R.id.patadd);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Patients.this, PatientE.class);
                startActivity(intent);
            }
        });
       // dis = findViewById(R.id.discharge_button);
        //dis.setOnClickListener(new View.OnClickListener() {
           // @Override
           // public void onClick(View v) {
                //Intent intent = new Intent(Patients.this, PatientE.class);
               // startActivity(intent);
            //}
        //});
        // rec = findViewById(R.id.records_button);
        //rec.setOnClickListener(new View.OnClickListener() {
        // @Override
        // public void onClick(View v) {
        //Intent intent = new Intent(Patients.this, PatientE.class);
        // startActivity(intent);
        //}
        //});

        //next = findViewById(R.id.next_button);
       // next.setOnClickListener(new View.OnClickListener() {
            //@Override
           // public void onClick(View v) {
                //Intent intent = new Intent(Patients.this, Admissions_Discharges.class);
              //  startActivity(intent);
           // }
        //});

        back = findViewById(R.id.back_button);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Patients.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    private void fetchPatients() {
        api.getPatients().enqueue(new Callback<List<PatientModel>>() {
            @Override
            public void onResponse(Call<List<PatientModel>> call, Response<List<PatientModel>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<PatientModel> patients = response.body();
                    Log.d("Patients", "Number of patients fetched: " + patients.size());
                    adapter = new PatientsAdapter(Patients.this,patients, api);
                    recyclerView.setAdapter(adapter);
                } else {
                    Log.d("Patients", "Failed to retrieve data: " + response.message());
                    Toast.makeText(Patients.this, "Failed to retrieve data", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<PatientModel>> call, Throwable t) {
                Log.d("Patients", "Error: " + t.getMessage());
                Toast.makeText(Patients.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void performSearch(String query) {
        String[] queryParts = query.split(" ");
        String name = queryParts.length > 0 ? queryParts[0] : "";
        String lastName = queryParts.length > 1 ? queryParts[1] : "";

        PatSearchDTO searchDTO = new PatSearchDTO(name, lastName);
        api.searchPatients(searchDTO).enqueue(new Callback<List<PatientModel>>() {
            @Override
            public void onResponse(Call<List<PatientModel>> call, Response<List<PatientModel>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<PatientModel> patients = response.body();
                    Log.d("Patientss", "Number of patients fetched: " + patients.size());
                    adapter = new PatientsAdapter(Patients.this,patients, api);
                    recyclerView.setAdapter(adapter);
                } else {
                    Log.d("Patientss", "Failed to retrieve data: " + response.message());
                    Toast.makeText(Patients.this, "Failed to retrieve data", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<PatientModel>> call, Throwable t) {
                Log.d("Patients", "Error: " + t.getMessage());
                Toast.makeText(Patients.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
