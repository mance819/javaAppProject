package com.example.projectapp;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class Admissions_Discharges extends AppCompatActivity {

        private EditText searchEditText;
        private Button addButton;
        private Button searchButton;
        private TableLayout tableLayout;
        Button admit;
        Button moveto;
    SearchView searchView;
    ListView myListView;
    ArrayList<String> arrayList;
    ArrayAdapter<String> adapter;

    Button back;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_admissions_discharges);
            searchView = findViewById(R.id.searchView);
            myListView = findViewById(R.id.listView);

            arrayList = new ArrayList<>();
            arrayList.add("Cardiology");
            arrayList.add("Dermatology");
            arrayList.add("Gynaecology");
            arrayList.add("Nephrology");

            adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, arrayList);
            myListView.setAdapter(adapter);

            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String s) {
                    return false;
                }

                @Override
                public boolean onQueryTextChange(String s) {
                    adapter.getFilter().filter(s);
                    return false;
                }
            });
            // Initialize views


            // Set click listeners
            admit = findViewById(R.id.admit);
            admit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(Admissions_Discharges.this,AdmissionCause.class);
                    startActivity(intent);
                }
            });
            moveto = findViewById(R.id.moveto);
            moveto.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(Admissions_Discharges.this,TransferCause.class);
                    startActivity(intent);
                }
            });

            back = findViewById(R.id.back);
            back.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(Admissions_Discharges.this,Patients.class);
                    startActivity(intent);
                }
            });



            ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });  // Set up the buttons

        }






        }

