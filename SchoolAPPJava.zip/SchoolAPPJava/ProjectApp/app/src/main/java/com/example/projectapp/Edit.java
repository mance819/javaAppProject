package com.example.projectapp;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.google.android.material.textfield.TextInputEditText;
import retrofit.DepartmentApi;
import retrofit.RetrofitService;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import models.DepartmentModel;

public class Edit extends AppCompatActivity {
    public static final String EXTRA_DEPARTMENT_ID = "null";
    private Long departmentId = null;

    Button cancel;
    Button done;
    TextInputEditText inputCodeText;
    TextInputEditText inputNameText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit);

        initializeComponents();

        // Get the department ID from the Intent
        if (getIntent().hasExtra(EXTRA_DEPARTMENT_ID)) {
            departmentId = getIntent().getLongExtra(EXTRA_DEPARTMENT_ID, -1L);
        }

        cancel.setOnClickListener(v -> {
            Intent intent = new Intent(Edit.this, Departments.class);
            startActivity(intent);
        });

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            done.setOnClickListener(v -> sendDepartmentData());
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void initializeComponents() {
        inputCodeText = findViewById(R.id.code);
        inputNameText = findViewById(R.id.depadd);
        cancel = findViewById(R.id.cancel_button);
        done = findViewById(R.id.done);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void sendDepartmentData() {
        String code = inputCodeText.getText().toString();
        String name = inputNameText.getText().toString();
        Log.d("hahs" , code );
        Log.d("hahs" , name );



        DepartmentModel department = new DepartmentModel(departmentId, code, name);

        DepartmentApi apiService = RetrofitService.getRetrofitInstance().create(DepartmentApi.class);

        Call<DepartmentModel> call = apiService.registerOrUpdateDepartment(department);

        Log.d("hahs" , call.toString() );
        call.enqueue(new Callback<DepartmentModel>() {
            @Override
            public void onResponse(Call<DepartmentModel> call, Response<DepartmentModel> response) {
                Log.d("hahs" , response.toString() );
                if (response.isSuccessful()) {
                    Toast.makeText(Edit.this, "Department " + (departmentId == -1 ? "added" : "updated") + " successfully", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Edit.this, Departments.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(Edit.this, "Failed to " + (departmentId == -1 ? "add" : "update") + " department", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<DepartmentModel> call, Throwable t) {
                Toast.makeText(Edit.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
