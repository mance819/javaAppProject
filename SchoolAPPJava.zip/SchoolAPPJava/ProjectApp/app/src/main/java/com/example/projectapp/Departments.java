package com.example.projectapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

import models.DepartmentAdapter;
import models.DepartmentModel;
import retrofit.DepartmentApi;
import retrofit.RetrofitService;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Departments extends AppCompatActivity {
    private RecyclerView recyclerView;
    private DepartmentAdapter adapter;
    private DepartmentApi departmentApi;
Button back;
    Button add;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_departments);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        departmentApi = RetrofitService.getRetrofitInstance().create(DepartmentApi.class);
        fetchDepartments();
        back = findViewById(R.id.back_button);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Departments.this, MainActivity.class);
                startActivity(intent);
            }
        });
        add = findViewById(R.id.buttonadd);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Departments.this, Edit.class);
                startActivity(intent);
            }
        });
    }

    private void fetchDepartments() {
        departmentApi.getDepartments().enqueue(new Callback<List<DepartmentModel>>() {
            @Override
            public void onResponse(Call<List<DepartmentModel>> call, Response<List<DepartmentModel>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<DepartmentModel> departments = response.body();
                    Log.d("Departments", "Number of departments fetched: " + departments.size());
                    adapter = new DepartmentAdapter(departments, departmentApi, Departments.this);
                    recyclerView.setAdapter(adapter);
                } else {
                    Log.d("Departments", "Failed to retrieve data: " + response.message());
                    Toast.makeText(Departments.this, "Failed to retrieve data", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<DepartmentModel>> call, Throwable t) {
                Log.d("Departments", "Error: " + t.getMessage());
                Toast.makeText(Departments.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

}
