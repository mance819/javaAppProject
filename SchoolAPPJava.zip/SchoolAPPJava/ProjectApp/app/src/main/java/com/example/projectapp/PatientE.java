package com.example.projectapp;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import models.PatientModel;
import retrofit.PatientApi;
import retrofit.RetrofitService;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PatientE extends AppCompatActivity {
    private Long patientId = null;
    Button cancel;
    Button done;
    TextInputEditText inputNameText;
    TextInputEditText inputSurNameText;
    TextInputEditText inputBirthdayText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("PATIENT_ID")) {
            patientId = intent.getLongExtra("PATIENT_ID", -1L);
            if (patientId == -1L) {
                patientId = null;
            }
        } else {
            patientId = null;
        }

        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_patient_e);
        cancel = findViewById(R.id.cancel_button);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PatientE.this, Patients.class);
                startActivity(intent);
            }
        });

        done = findViewById(R.id.done);
        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PatientE.this, Patients.class);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                   sendPatientData();
               }
                startActivity(intent);
            }
        });
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        initializeComponents();
    }

    private void initializeComponents() {
        inputNameText = findViewById(R.id.name);
        inputSurNameText = findViewById(R.id.surname);
        inputBirthdayText = findViewById(R.id.birthday);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void sendPatientData() {
        String name = inputNameText.getText().toString();
        String surname = inputSurNameText.getText().toString();
        String birthdaystr = inputBirthdayText.getText().toString();



        PatientModel patient = new PatientModel(patientId,name, surname, birthdaystr);

        PatientApi apiService = RetrofitService.getRetrofitInstance().create(PatientApi.class);
        Call<PatientModel> call = apiService.registerOrUpdatePatient(patient);
        Log.d("PatientE", call.toString());

        //call eshte push request
        call.enqueue(new Callback<PatientModel>() {
            @Override
            public void onResponse(Call<PatientModel> call, Response<PatientModel> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(PatientE.this, "Patient added successfully", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(PatientE.this, Patients.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(PatientE.this, "Failed to add patient", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<PatientModel> call, Throwable t) {
                Toast.makeText(PatientE.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
