package retrofit;

import java.util.List;

import models.PatDelDTO;
import models.PatSearchDTO;
import models.PatientModel;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.HTTP;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface PatientApi {

    @GET("/api/v1/patient")
    Call<List<PatientModel>> getPatients();


    @POST("/api/v1/patient")
    Call<PatientModel> registerOrUpdatePatient (@Body PatientModel patientModel);

    @HTTP(method = "DELETE", path = "/api/v1/patient", hasBody = true)
    Call<Void> deletePatient(@Body PatDelDTO deleteDTO);

    @POST("/api/v1/patient/search")
    Call<List<PatientModel>> searchPatients( PatSearchDTO searchDTO);







}
