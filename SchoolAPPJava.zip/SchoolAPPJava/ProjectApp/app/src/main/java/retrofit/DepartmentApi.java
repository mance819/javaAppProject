package retrofit;

import java.util.List;

import models.DepDelDTO;
import models.DepartmentModel;
import models.PatDelDTO;
import models.PatSearchDTO;
import models.PatientModel;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.HTTP;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface DepartmentApi {

    @GET("/api/v1/department")
    Call<List<DepartmentModel>> getDepartments();


    @POST("/api/v1/department")
    Call<DepartmentModel> registerOrUpdateDepartment(@Body DepartmentModel DepartmentModel);

    @HTTP(method = "DELETE", path = "/api/v1/department", hasBody = true)
    Call<Void> deleteDepartment(@Body DepDelDTO deleteDTO);

    @POST("/api/v1/department/search")
    Call<List<DepartmentModel>> searchDepartments( PatSearchDTO searchDTO);








}
