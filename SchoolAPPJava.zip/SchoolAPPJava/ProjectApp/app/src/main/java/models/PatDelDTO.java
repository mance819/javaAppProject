package models;

public class PatDelDTO {
    private Long id;

    public PatDelDTO(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
