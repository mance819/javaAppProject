package models;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.projectapp.Admissions_Discharges;
import com.example.projectapp.ClinicalRecords;
import com.example.projectapp.DischargeReason;
import com.example.projectapp.PatientE;
import com.example.projectapp.Patients;
import com.example.projectapp.R;

import java.util.List;

import retrofit.PatientApi;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PatientsAdapter extends RecyclerView.Adapter<PatientsAdapter.ViewHolder> {
    private List<PatientModel> patients;
    private PatientApi patientApi;
    private Context context;


    public PatientsAdapter(Context context,List<PatientModel> patients, PatientApi patientApi) {
        this.patients = patients;
        this.patientApi = patientApi;
        this.context = context;
    }

    public void updatePatients(List<PatientModel> newPatients) {
        this.patients = newPatients;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_patient, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        PatientModel patient = patients.get(position);
        holder.patientId.setText(String.valueOf(patient.getId()));
        holder.patientName.setText(patient.getName() + " " + patient.getLastName());
        holder.birthday.setText(patient.getBirthDate());

        holder.deleteButton.setOnClickListener(v -> {
            Long patientId = patient.getId();
            deletePatient(new PatDelDTO(patientId), position);
        });

        holder.editButton.setOnClickListener(v -> {
            Intent intent = new Intent(v.getContext(), PatientE.class);
            intent.putExtra("PATIENT_ID", patient.getId());
            v.getContext().startActivity(intent);
        });

        holder.nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, Admissions_Discharges.class);
                context.startActivity(intent);
            }
        });
        holder.dischargeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, DischargeReason.class);
                context.startActivity(intent);
            }
        });

        holder.recordsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, ClinicalRecords.class);
                context.startActivity(intent);
            }
        });



        // Other button click handlers...
    }

    private void deletePatient(PatDelDTO deleteDTO, int position) {
        patientApi.deletePatient(deleteDTO).enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    // Remove the item from the list and notify the adapter
                    patients.remove(position);
                    notifyItemRemoved(position);
                    notifyItemRangeChanged(position, patients.size());
                } else {
                    // Handle failure (e.g., show a toast or log an error)
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                // Handle failure (e.g., show a toast or log an error)
            }
        });
    }

    @Override
    public int getItemCount() {
        return patients.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView patientId, patientName, birthday;
        Button deleteButton, editButton, nextButton, dischargeButton, recordsButton;

        public ViewHolder(View itemView) {
            super(itemView);
            patientId = itemView.findViewById(R.id.patient_id);
            patientName = itemView.findViewById(R.id.patient_name);
            birthday = itemView.findViewById(R.id.birthday);
            deleteButton = itemView.findViewById(R.id.delete_button);
            editButton = itemView.findViewById(R.id.edit_button);
            nextButton = itemView.findViewById(R.id.next_button);
            dischargeButton = itemView.findViewById(R.id.discharge_button);
            recordsButton = itemView.findViewById(R.id.records_button);
        }
    }
}
