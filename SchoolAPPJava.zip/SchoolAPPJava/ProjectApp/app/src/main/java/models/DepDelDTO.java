package models;

public class DepDelDTO {
    private Long id;

    public DepDelDTO(Long id) {
        this.id = id;
    }

    public DepDelDTO() {

    }
    public Long getId() {
        return id;
    }
}
