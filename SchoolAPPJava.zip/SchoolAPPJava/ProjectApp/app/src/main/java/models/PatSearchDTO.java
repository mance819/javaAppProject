package models;

public class PatSearchDTO {
    private String name;
    private String lastName;

    public PatSearchDTO(String name, String lastName) {
        this.name = name;
        this.lastName = lastName;
    }

    public PatSearchDTO() {
    }

    public String getName() {
        return name;
    }

    public String getLastName() {
        return lastName;
    }
}