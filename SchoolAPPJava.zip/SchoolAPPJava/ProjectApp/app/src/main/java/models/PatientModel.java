package models;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class PatientModel {
    private Long id = null;
    private String name;
    private String lastName;
    private String birthDate;


    public  PatientModel(){

    }
    public PatientModel(String name, String lastName, String birthDate) {
        this.name = name;
        this.lastName = lastName;
        this.birthDate = birthDate;
    }
    // Constructor
    public  PatientModel(Long id, String name, String lastName, String birthDate) {
        this.id = id;
        this.name = name;
        this.lastName = lastName;
        this.birthDate = birthDate;
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }



}
