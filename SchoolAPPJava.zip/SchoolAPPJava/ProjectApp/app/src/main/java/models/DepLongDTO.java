package models;

public class DepLongDTO {
    private Long id;

    public DepLongDTO(Long id) {
        this.id = id;
    }

    public DepLongDTO() {

    }
    public Long getId() {
        return id;
    }


}

