package models;

public class ClinicalData {

    private Long id;
    private String clinicalRecord;

    private Long patientId;

    public ClinicalData() {
    }

    public ClinicalData(Long id, String clinicalRecord, Long patientId) {
        this.id = id;
        this.clinicalRecord = "";
        this.patientId = patientId;
    }
    public ClinicalData(String clinicalRecord, Long patientId) {
        this.clinicalRecord = clinicalRecord;
        this.patientId = patientId;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getClinicalRecord() {
        return clinicalRecord;
    }

    public void setClinicalRecord(String clinicalRecord) {
        this.clinicalRecord = clinicalRecord;
    }

    public Long getPatientId() {
        return patientId;
    }
    public void setPatientId(Long patientId) {
        this.patientId = patientId;
    }



}
