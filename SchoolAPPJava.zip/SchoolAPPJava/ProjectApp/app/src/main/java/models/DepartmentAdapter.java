package models;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.projectapp.Edit;
import com.example.projectapp.R;

import java.util.List;

import retrofit.DepartmentApi;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DepartmentAdapter extends RecyclerView.Adapter<DepartmentAdapter.ViewHolder> {
    private List<DepartmentModel> departments;
    private DepartmentApi departmentApi;
    private Context context;

    public DepartmentAdapter(List<DepartmentModel> departments, DepartmentApi departmentApi, Context context) {
        this.departments = departments;
        this.departmentApi = departmentApi;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_department, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        DepartmentModel department = departments.get(position);
        holder.departmentId.setText(String.valueOf(department.getId()));
        holder.departmentName.setText(department.getName());
        holder.departmentCode.setText(department.getCode());

        holder.editButton.setOnClickListener(v -> {
            Long departmentId = department.getId();
            Intent intent = new Intent(context, Edit.class);
            intent.putExtra(Edit.EXTRA_DEPARTMENT_ID, departmentId);
            context.startActivity(intent);
        });

        holder.deleteButton.setOnClickListener(v -> {
            Long departmentId = department.getId();
            showDeleteConfirmationDialog(departmentId, position);
        });
    }

    private void showDeleteConfirmationDialog(Long departmentId, int position) {
        new AlertDialog.Builder(context)
                .setTitle("Delete Department")
                .setMessage("Are you sure you want to delete this department?")
                .setPositiveButton("Yes", (dialog, which) -> deleteDepartment(new DepDelDTO(departmentId), position))
                .setNegativeButton("No", null)
                .show();
    }

    private void deleteDepartment(DepDelDTO deleteDTO, int position) {
        departmentApi.deleteDepartment(deleteDTO).enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    // Remove the item from the list and notify the adapter
                    departments.remove(position);
                    notifyItemRemoved(position);
                    notifyItemRangeChanged(position, departments.size());
                } else {
                    // Handle failure (e.g., show a toast or log an error)
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                // Handle failure (e.g., show a toast or log an error)
            }
        });
    }

    @Override
    public int getItemCount() {
        return departments.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView departmentId, departmentName,departmentCode;
        Button deleteButton, editButton;

        public ViewHolder(View itemView) {
            super(itemView);
            departmentId = itemView.findViewById(R.id.department_id);
            departmentName = itemView.findViewById(R.id.department_name);
            departmentCode = itemView.findViewById(R.id.department_code);
            deleteButton = itemView.findViewById(R.id.delete_button);
            editButton = itemView.findViewById(R.id.edit_button);
        }
    }
}
