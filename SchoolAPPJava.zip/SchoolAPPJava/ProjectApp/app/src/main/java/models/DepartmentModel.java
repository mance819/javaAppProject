package models;

public class DepartmentModel {

    private Long id;
    private String code;
    private String name;

    public  DepartmentModel() {

    }
    public  DepartmentModel(Long id, String code, String name) {
        this.id = id;
        this.code = "";
        this.name = "";
    }
    public  DepartmentModel( String code, String name) {

        this.code = "";
        this.name = "";
    }
    // Constructor


    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
