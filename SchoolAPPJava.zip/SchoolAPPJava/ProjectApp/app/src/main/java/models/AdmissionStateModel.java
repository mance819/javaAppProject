package models;

import android.os.Build;

import java.time.LocalDateTime;

public class AdmissionStateModel {
    private Long id;
    private LocalDateTime enteringDate;
    private LocalDateTime exitingDate;
    private String cause;
    private String reason;
    private boolean discharge;
    private long patientId;
    private long departmentId;
    public void AdmissionState() {
    }
    public void AdmissionState(Long Id, LocalDateTime enteringDate, LocalDateTime exitingDate, String cause, String reason, boolean discharge, long patientId, long departmentId) {
        this.id = Id;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            this.enteringDate = LocalDateTime.now();
        }
        this.exitingDate = null;
        this.cause = "";
        this.reason = "";
        this.discharge = false;
        this.patientId = patientId;
        this.departmentId = departmentId;
    }

    public void AdmissionState( LocalDateTime enteringDate, LocalDateTime exitingDate, String cause, String reason, boolean discharge,long patientId, long departmentId) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            this.enteringDate = LocalDateTime.now();
        }
        this.exitingDate = null;
        this.cause = "";
        this.reason = "";
        this.discharge = false;
        this.patientId = patientId;
        this.departmentId = departmentId;
    }
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDateTime getEnteringDate() {
        return enteringDate;
    }

    public void setEnteringDate(LocalDateTime enteringDate) {
        this.enteringDate = enteringDate;
    }

    public LocalDateTime getExitingDate() {
        return exitingDate;
    }

    public void setExitingDate(LocalDateTime exitingDate) {
        this.exitingDate = exitingDate;
    }

    public String getCause() {
        return cause;
    }

    public void setCause(String cause) {
        this.cause = cause;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public boolean isDischarge() {
        return discharge;
    }

    public void setDischarge(boolean discharge) {
        this.discharge = discharge;
    }

    public long getPatientId() {
        return patientId;
    }
    public void setPatientId(long patientId) {
        this.patientId = patientId;
    }
    public long getDepartmentId() {
        return departmentId;
    }
    public void setDepartmentId(long departmentId) {
        this.departmentId = departmentId;
    }
}
