package com.SchoProjApp.ProjectWork.Models.Patients;

import org.springframework.context.annotation.Configuration;

@Configuration
public class PatientConfig {

}

