package com.SchoProjApp.ProjectWork.Models.Patients.dto;

import java.time.LocalDate;

public class PatUpsertDTO {
    private Long id;
    private String name;
    private String lastName;
    private LocalDate birthDate;

    public PatUpsertDTO(Long id,String name, String lastName, LocalDate birthDate) {
        this.id = id;
        this.name = name;
        this.lastName = lastName;
        this.birthDate = birthDate;
    }

    public PatUpsertDTO() {
    }

    public String getName() {
        return name;
    }

    public String getLastName() {
        return lastName;
    }

    public LocalDate getBirthDate() {
        return birthDate;
    }

    public Long getId() {
        return id;
    }
}
