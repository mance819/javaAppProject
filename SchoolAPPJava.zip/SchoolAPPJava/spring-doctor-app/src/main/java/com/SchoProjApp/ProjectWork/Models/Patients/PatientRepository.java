package com.SchoProjApp.ProjectWork.Models.Patients;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PatientRepository extends JpaRepository<Patient, Long> {

    Optional<Patient> findPatientByNameAndLastName(String name,String lastName);
    Optional<Patient> findPatientByNameOrLastName(String name, String lastName);


}
