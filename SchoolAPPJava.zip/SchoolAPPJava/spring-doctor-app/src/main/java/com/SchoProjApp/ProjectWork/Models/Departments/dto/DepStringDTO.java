package com.SchoProjApp.ProjectWork.Models.Departments.dto;

public class DepStringDTO {

    private String name;

    public DepStringDTO(String name) {
        this.name = name;
    }

    public DepStringDTO() {
    }

    public String getName() {
        return name;
    }
}
