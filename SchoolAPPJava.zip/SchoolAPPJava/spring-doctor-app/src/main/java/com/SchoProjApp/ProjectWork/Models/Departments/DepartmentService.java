package com.SchoProjApp.ProjectWork.Models.Departments;

import com.SchoProjApp.ProjectWork.Models.Departments.dto.DepLongDTO;
import com.SchoProjApp.ProjectWork.Models.Departments.dto.DepStringDTO;
import com.SchoProjApp.ProjectWork.Models.Departments.dto.DepartmentDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class DepartmentService {

    private final DepartmentRepository departmentRepository;

    @Autowired
    public DepartmentService(DepartmentRepository departmentRepository) {
        this.departmentRepository = departmentRepository;
    }

    public List<DepartmentDTO> getDepartments() {
        return departmentRepository.findAll().stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    public void addNewDepartment(DepartmentDTO departmentDTO) {
        Department department = new Department(departmentDTO.getName(), departmentDTO.getCode());
        departmentRepository.findDepartmentByName(department.getName())
                .ifPresentOrElse(
                        d -> {
                            throw new IllegalStateException("Department already exists");
                        },
                        () -> {
                            departmentRepository.save(department);
                        }
                );
    }

    @Transactional
    public void updateDepartment(DepartmentDTO departmentDTO) {
        Department department = departmentRepository.findById(departmentDTO.getId())
                .orElseThrow(() -> new IllegalStateException(
                        "Department with id " + departmentDTO.getId() + " does not exist"
                ));

        if (departmentDTO.getName() != null && departmentDTO.getName().length() > 0 && !departmentDTO.getName().equals(department.getName())) {
            department.setName(departmentDTO.getName());
        }

        if (departmentDTO.getCode() != null && departmentDTO.getCode().length() > 0 && !departmentDTO.getCode().equals(department.getCode())) {
            department.setCode(departmentDTO.getCode());
        }
    }

    public void deleteDepartment(DepLongDTO deleteDTO) {
        departmentRepository.deleteById(deleteDTO.getId());
    }

    public List<DepartmentDTO> searchDepartments(DepStringDTO searchDTO) {
        return departmentRepository.findDepartmentByNameContaining(searchDTO.getName()).stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    private DepartmentDTO convertToDTO(Department department) {
        DepartmentDTO departmentDTO = new DepartmentDTO();
        departmentDTO.setId(department.getId());
        departmentDTO.setName(department.getName());
        departmentDTO.setCode(department.getCode());
        return departmentDTO;
    }
}

