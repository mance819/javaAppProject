package com.SchoProjApp.ProjectWork.Models.ClinicalData.dto;

public class ClinSearchDTO {
    private String data;
    private Long patId;

    public ClinSearchDTO(String data, Long patId) {
        this.data = data;
        this.patId = patId;
    }

    public ClinSearchDTO() {
    }

    public String getData() {
        return data;
    }

    public Long getPatId() {
        return patId;
    }

}
