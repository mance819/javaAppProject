package com.SchoProjApp.ProjectWork.Models.Admissions;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface AdmissionStateRepository extends JpaRepository<AdmissionState, Long> {

    Optional<AdmissionState> findAdmissionStateByPatientId(Long patientId);

    @Query("SELECT a FROM AdmissionState a WHERE a.patientId = :patientId AND a.exitingDate IS NULL")
    Optional<AdmissionState> findAdmissionStateByPatientIdAndExitingDateIsNull(@Param("patientId") Long patientId);
}