package com.SchoProjApp.ProjectWork.Models.ClinicalData;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ClinicalDataRepository extends JpaRepository<ClinicalData, Long> {

    Optional<ClinicalData> findClinicalDataById(Long Id);
    List<ClinicalData> findClinicalDataByPatientId(Long patientId);

    List<ClinicalData> findClinicalDataByClinicalRecordAndPatientId(String clinicalRecord, Long patientId);
}
