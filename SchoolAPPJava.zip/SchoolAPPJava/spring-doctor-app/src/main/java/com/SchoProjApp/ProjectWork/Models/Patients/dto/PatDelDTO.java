package com.SchoProjApp.ProjectWork.Models.Patients.dto;

public class PatDelDTO {

    private Long id;

    public PatDelDTO(Long id) {
        this.id = id;
    }

    public PatDelDTO() {
    }

    public Long getId() {
        return id;
    }
}
