package com.SchoProjApp.ProjectWork.Models.Admissions;
import jakarta.persistence.*;

import java.time.LocalDate;
import java.time.LocalDateTime;


@Entity
@Table
public class AdmissionState {
    @Id
    @SequenceGenerator(
            name = "admission_state_sequence",
            sequenceName = "admission_state_sequence",
            allocationSize = 1
    )
    @GeneratedValue(
            strategy = jakarta.persistence.GenerationType.SEQUENCE,
            generator = "admission_state_sequence"
    )
    private Long id;
    private LocalDate enteringDate;
    private LocalDate exitingDate;
    private String cause;
    private String reason;
    private boolean discharge;
    private long patientId;
    private long departmentId;

    public AdmissionState() {

    }
    public AdmissionState( Long Id,LocalDate enteringDate, LocalDate exitingDate, String cause, String reason, boolean discharge,long patientId, long departmentId) {
        this.id = Id;
        this.enteringDate = LocalDate.now();
        this.exitingDate = exitingDate;
        this.cause = cause;
        this.reason = reason;
        this.discharge = discharge;
        this.patientId = patientId;
        this.departmentId = departmentId;
    }

    public AdmissionState( LocalDate enteringDate, LocalDate exitingDate, String cause, String reason, boolean discharge,long patientId, long departmentId) {
        this.enteringDate = LocalDate.now();
        this.exitingDate = exitingDate;
        this.cause = cause;
        this.reason = reason;
        this.discharge = discharge;
        this.patientId = patientId;
        this.departmentId = departmentId;
    }
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getEnteringDate() {
        return enteringDate;
    }

    public void setEnteringDate(LocalDate enteringDate) {
        this.enteringDate = enteringDate;
    }

    public LocalDate getExitingDate() {
        return exitingDate;
    }

    public void setExitingDate(LocalDate exitingDate) {
        this.exitingDate = exitingDate;
    }

    public String getCause() {
        return cause;
    }

    public void setCause(String cause) {
        this.cause = cause;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public boolean isDischarge() {
        return discharge;
    }

    public void setDischarge(boolean discharge) {
        this.discharge = discharge;
    }

    public long getPatientId() {
        return patientId;
    }
    public void setPatientId(long patientId) {
        this.patientId = patientId;
    }
    public long getDepartmentId() {
        return departmentId;
    }
    public void setDepartmentId(long departmentId) {
        this.departmentId = departmentId;
    }
}
