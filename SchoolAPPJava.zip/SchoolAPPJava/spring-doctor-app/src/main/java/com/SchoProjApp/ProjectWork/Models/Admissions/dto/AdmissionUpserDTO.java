package com.SchoProjApp.ProjectWork.Models.Admissions.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class AdmissionUpserDTO {
    private Long id;
    private LocalDate enteringDate;
    private LocalDate exitingDate;
    private String cause;
    private String reason;
    private boolean discharge;
    private long patientId;
    private long departmentId;

    public AdmissionUpserDTO() {
    }

    public AdmissionUpserDTO(Long id, LocalDate enteringDate, LocalDate exitingDate, String cause, String reason, boolean discharge, long patientId, long departmentId) {
        this.id = id;
        this.enteringDate = enteringDate;
        this.exitingDate = exitingDate;
        this.cause = cause;
        this.reason = reason;
        this.discharge = discharge;
        this.patientId = patientId;
        this.departmentId = departmentId;
    }

    public Long getId() {
        return id;
    }

    public LocalDate getEnteringDate() {
        return enteringDate;
    }

    public LocalDate getExitingDate() {
        return exitingDate;
    }

    public String getCause() {
        return cause;
    }

    public String getReason() {
        return reason;
    }

    public boolean isDischarge() {
        return discharge;
    }

    public long getPatientId() {
        return patientId;
    }

    public long getDepartmentId() {
        return departmentId;
    }
}