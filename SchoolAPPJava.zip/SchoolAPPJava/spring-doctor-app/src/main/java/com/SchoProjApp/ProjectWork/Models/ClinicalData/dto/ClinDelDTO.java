package com.SchoProjApp.ProjectWork.Models.ClinicalData.dto;

public class ClinDelDTO {

    private Long id;

    public ClinDelDTO(Long id) {
        this.id = id;
    }

    public ClinDelDTO() {
    }

    public Long getId() {
        return id;
    }


}
