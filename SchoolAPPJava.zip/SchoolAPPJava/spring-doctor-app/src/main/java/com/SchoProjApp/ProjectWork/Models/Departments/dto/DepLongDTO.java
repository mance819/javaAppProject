package com.SchoProjApp.ProjectWork.Models.Departments.dto;

public class DepLongDTO {
    private Long id;

    public DepLongDTO(Long id) {
        this.id = id;
    }

    public DepLongDTO() {

    }
    public Long getId() {
        return id;
    }


}
