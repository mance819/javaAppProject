package com.SchoProjApp.ProjectWork.Models.ClinicalData;


import com.SchoProjApp.ProjectWork.Models.ClinicalData.dto.ClinDelDTO;
import com.SchoProjApp.ProjectWork.Models.ClinicalData.dto.ClinSearchDTO;
import com.SchoProjApp.ProjectWork.Models.ClinicalData.dto.ClinUpsertDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "api/v1/clinicaldata")
public class ClinicalDataController {

    private final ClinicalDataService clinicalDataService;

    @Autowired
    public ClinicalDataController(ClinicalDataService clinicalDataService) {
        this.clinicalDataService = clinicalDataService;
    }

    @GetMapping
    public List<ClinUpsertDTO> getClinicalData() {
        return clinicalDataService.getClinicalData();
    }

    @PostMapping
    public void registerOrUpdateClinicalData(@RequestBody ClinUpsertDTO clinicalDataDTO) {
        if (clinicalDataDTO.getId() == null) {
            clinicalDataService.addNewClinicalData(clinicalDataDTO);
        } else {
            clinicalDataService.updateClinicalData(clinicalDataDTO);
        }
    }

    @DeleteMapping
    public void deleteClinicalData(@RequestBody ClinDelDTO deleteDTO) {
        clinicalDataService.deleteClinicalData(deleteDTO);
    }

    @PostMapping("/search")
    public List<ClinUpsertDTO> searchClinicalData(@RequestBody ClinSearchDTO searchDTO) {
        return clinicalDataService.getClinicalDataByPatientId(searchDTO);
    }
    @PostMapping("/searchRec/{id}")
    public List<ClinUpsertDTO> getClinicalDataByClinicalRecordAndPatientId(@RequestBody ClinSearchDTO searchDTO) {
        return clinicalDataService.getClinicalDataByClinicalRecordAndPatientId(searchDTO);
    }

}
