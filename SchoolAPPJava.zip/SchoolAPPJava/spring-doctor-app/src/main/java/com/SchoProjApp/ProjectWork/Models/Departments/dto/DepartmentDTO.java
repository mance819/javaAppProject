package com.SchoProjApp.ProjectWork.Models.Departments.dto;

public class DepartmentDTO {

    private Long id;
    private String name;
    private String code;

    public DepartmentDTO( String name, String code) {

        this.name = name;
        this.code = code;
    }

    public DepartmentDTO(Long id, String name, String code) {
        this.id = id;
        this.name = name;
        this.code = code;
    }

    public DepartmentDTO() {
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getCode() {
        return code;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCode(String code) {
        this.code = code;
    }

}
