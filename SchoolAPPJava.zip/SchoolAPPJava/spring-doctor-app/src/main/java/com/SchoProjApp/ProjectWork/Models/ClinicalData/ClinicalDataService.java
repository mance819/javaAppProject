package com.SchoProjApp.ProjectWork.Models.ClinicalData;


import com.SchoProjApp.ProjectWork.Models.ClinicalData.dto.ClinDelDTO;
import com.SchoProjApp.ProjectWork.Models.ClinicalData.dto.ClinSearchDTO;
import com.SchoProjApp.ProjectWork.Models.ClinicalData.dto.ClinUpsertDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ClinicalDataService {

    private final ClinicalDataRepository clinicalDataRepository;

    @Autowired
    public ClinicalDataService(ClinicalDataRepository clinicalDataRepository) {
        this.clinicalDataRepository = clinicalDataRepository;
    }

    public List<ClinUpsertDTO> getClinicalData() {
        return clinicalDataRepository.findAll().stream()
                .map(clinicalData -> new ClinUpsertDTO(clinicalData.getId(), clinicalData.getClinicalRecord(),clinicalData.getPatientId()))
                .collect(java.util.stream.Collectors.toList());
    }

    public void addNewClinicalData(ClinUpsertDTO clinUpsertDTO) {
        ClinicalData clinicalData = new ClinicalData(clinUpsertDTO.getId() , clinUpsertDTO.getClinicalRecord(),clinUpsertDTO.getPatientId());
        clinicalDataRepository.findClinicalDataById(clinUpsertDTO.getId())
                .ifPresentOrElse(
                        c -> {
                            throw new IllegalStateException("Clinical Data already exists");
                        },
                        () -> {
                            clinicalDataRepository.save(clinicalData);
                        }
                );
    }

    @Transactional
    public void updateClinicalData(ClinUpsertDTO clinUpsertDTO) {
        Long clinicalDataId = clinUpsertDTO.getId();
        ClinicalData clinicalData = clinicalDataRepository.findById(clinicalDataId)
                .orElseThrow(() -> new IllegalStateException(
                        "Clinical Data with id " + clinicalDataId + " does not exist"
                ));

        if (clinUpsertDTO.getClinicalRecord() != null && clinUpsertDTO.getClinicalRecord().length() > 0 && !clinUpsertDTO.getClinicalRecord().equals(clinicalData.getClinicalRecord())) {
            clinicalData.setClinicalRecord(clinUpsertDTO.getClinicalRecord());
        }

        if (clinUpsertDTO.getPatientId() != null && !clinUpsertDTO.getPatientId().equals(clinicalData.getPatientId())) {
            clinicalData.setPatientId(clinUpsertDTO.getPatientId());
        }
    }

    public void deleteClinicalData(ClinDelDTO clinDelDTO) {
        ClinicalData clinicalData = clinicalDataRepository.findById(clinDelDTO.getId())
                .orElseThrow(() -> new IllegalStateException(
                        "Clinical Data with id " + clinDelDTO.getId() + " does not exist"
                ));
        clinicalDataRepository.delete(clinicalData);
    }

    public List<ClinUpsertDTO> getClinicalDataByPatientId(ClinSearchDTO ClinSearchDTO) {
        Long patientId = ClinSearchDTO.getPatId();
        List<ClinUpsertDTO> results = clinicalDataRepository.findClinicalDataByPatientId(patientId).stream()
                .map(clinicalData -> new ClinUpsertDTO(clinicalData.getId(), clinicalData.getClinicalRecord(),clinicalData.getPatientId()))
                .collect(java.util.stream.Collectors.toList());
        return results;
    }

    public List<ClinUpsertDTO> getClinicalDataByClinicalRecordAndPatientId(ClinSearchDTO ClinSearchDTO) {
        return clinicalDataRepository.findClinicalDataByClinicalRecordAndPatientId(ClinSearchDTO.getData(), ClinSearchDTO.getPatId()).stream()
                .map(clinicalData -> new ClinUpsertDTO(clinicalData.getId(), clinicalData.getClinicalRecord(),clinicalData.getPatientId()))
                .collect(java.util.stream.Collectors.toList());
    }



}
