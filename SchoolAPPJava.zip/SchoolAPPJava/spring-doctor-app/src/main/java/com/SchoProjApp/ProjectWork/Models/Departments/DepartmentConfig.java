package com.SchoProjApp.ProjectWork.Models.Departments;

public class DepartmentConfig {
}
