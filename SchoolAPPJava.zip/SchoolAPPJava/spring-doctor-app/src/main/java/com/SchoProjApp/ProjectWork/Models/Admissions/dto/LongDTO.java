package com.SchoProjApp.ProjectWork.Models.Admissions.dto;

public class LongDTO {
    private Long patientId;

    public LongDTO() {
    }

    public LongDTO(Long patientId) {
        this.patientId = patientId;
    }

    public Long getPatientId() {
        return patientId;
    }
}
