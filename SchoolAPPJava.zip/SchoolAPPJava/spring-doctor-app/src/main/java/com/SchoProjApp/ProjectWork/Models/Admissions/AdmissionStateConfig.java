package com.SchoProjApp.ProjectWork.Models.Admissions;

import org.springframework.context.annotation.Configuration;

@Configuration
public class AdmissionStateConfig {
}
