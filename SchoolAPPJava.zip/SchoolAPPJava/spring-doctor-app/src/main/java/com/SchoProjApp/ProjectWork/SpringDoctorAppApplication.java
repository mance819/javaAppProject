package com.SchoProjApp.ProjectWork;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDoctorAppApplication {

	public static void main(String[] args) {

		SpringApplication.run(SpringDoctorAppApplication.class, args);

	}

}
