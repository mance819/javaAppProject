package com.SchoProjApp.ProjectWork.Models.Admissions;


import com.SchoProjApp.ProjectWork.Models.Admissions.dto.AdmissionUpserDTO;
import com.SchoProjApp.ProjectWork.Models.Admissions.dto.LongDTO;
import com.SchoProjApp.ProjectWork.Models.Patients.dto.PatUpsertDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/api/v1/admission")
public class AdmissionStateController {
    private final AdmissionStateService admissionStateService;


    @GetMapping
    public List<AdmissionUpserDTO> getAdmissions() {
        return admissionStateService.getAdmissions();
    }

    @Autowired
    public AdmissionStateController(AdmissionStateService admissionStateService) {
        this.admissionStateService = admissionStateService;
    }

    @PostMapping
    public void registerOrUpdateAdmissionState(@RequestBody AdmissionUpserDTO admissionState) {
        if (admissionState.getId() == null) {
            admissionStateService.addNewAdmissionState(admissionState);
        } else {
            admissionStateService.updateAdmissionState(admissionState);
        }
    }
    @PostMapping("/search")
    public List<AdmissionUpserDTO> findAdmissionStatebyPatientID(@RequestBody LongDTO admissionState) {

        return admissionStateService.findAdmissionStatebyPatientID(admissionState);
    }

    @DeleteMapping(path = "{admissionStateId}")
    public void deleteAdmissionState(@PathVariable("admissionStateId") Long admissionStateId) {
        admissionStateService.deleteAdmissionState(admissionStateId);
    }







}
