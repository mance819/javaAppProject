package com.SchoProjApp.ProjectWork.Models.Patients;

import com.SchoProjApp.ProjectWork.Models.Patients.dto.PatDelDTO;
import com.SchoProjApp.ProjectWork.Models.Patients.dto.PatSearchDTO;
import com.SchoProjApp.ProjectWork.Models.Patients.dto.PatUpsertDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class PatientService {
    private final PatientRepository patientRepository;
    @Autowired
    public PatientService(PatientRepository patientRepository) {
        this.patientRepository = patientRepository;
    }

    public List<PatUpsertDTO> getPatients() {
        return patientRepository.findAll().stream()
                .map(patient -> new PatUpsertDTO(patient.getId(), patient.getName(), patient.getLastName(), patient.getBirthDate()))
                .collect(Collectors.toList());
    }

    public void addNewPatient(PatUpsertDTO patUpsertDTO) {
        Patient patient = new Patient(patUpsertDTO.getId(), patUpsertDTO.getName(), patUpsertDTO.getLastName(), patUpsertDTO.getBirthDate());
        patientRepository.findPatientByNameAndLastName(patient.getName(),patient.getLastName())
                .ifPresentOrElse(
                        p -> {
                            throw new IllegalStateException("Patient already exists");
                        },
                        () -> {
                            patientRepository.save(patient);
                        }
                );
    }
    @Transactional
    public void updatePatient(PatUpsertDTO patientDTO) {
        Long patientId = patientDTO.getId();
        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new IllegalStateException(
                        "Patient with id " + patientId + " does not exist"
                ));

        if (patientDTO.getName() != null && patientDTO.getName().length() > 0 && !patientDTO.getName().equals(patient.getName())) {
            patient.setName(patientDTO.getName());
        }

        if (patientDTO.getLastName() != null && patientDTO.getLastName().length() > 0 && !patientDTO.getLastName().equals(patient.getLastName())) {
            patient.setLastName(patientDTO.getLastName());
        }

        if(patientDTO.getBirthDate() != null && !patientDTO.getBirthDate().equals(patient.getBirthDate())){
            patient.setBirthDate(patientDTO.getBirthDate());
        }
    }

    public void deletePatient(PatDelDTO deleteDTO) {
        Long patientId = deleteDTO.getId();
        boolean exits = patientRepository.existsById(patientId);
        if (!exits) {
            throw new IllegalStateException("Patient with id " + patientId + " does not exist");
        }
        patientRepository.deleteById(patientId);
    }

    public List<PatUpsertDTO> searchPatients(PatSearchDTO searchDTO) {
        return patientRepository.findPatientByNameOrLastName(searchDTO.getName(), searchDTO.getLastName()).stream()
                .map(patient -> new PatUpsertDTO(patient.getId(), patient.getName(), patient.getLastName(), patient.getBirthDate()))
                .collect(Collectors.toList());
    }

}
