package com.SchoProjApp.ProjectWork.Models.Departments;

import com.SchoProjApp.ProjectWork.Models.Departments.dto.DepLongDTO;
import com.SchoProjApp.ProjectWork.Models.Departments.dto.DepStringDTO;
import com.SchoProjApp.ProjectWork.Models.Departments.dto.DepartmentDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/api/v1/department")
public class DepartmentController {

    private final DepartmentService departmentService;

    @Autowired
    public DepartmentController(DepartmentService departmentService) {
        this.departmentService = departmentService;
    }

    @GetMapping
    public List<DepartmentDTO> getDepartments() {
        return departmentService.getDepartments();
    }

    @PostMapping
    public void registerOrUpdateDepartment(@RequestBody DepartmentDTO departmentDTO) {
        if (departmentDTO.getId() == null) {
            departmentService.addNewDepartment(departmentDTO);
        } else {
            departmentService.updateDepartment(departmentDTO);
        }
    }

    @DeleteMapping
    public void deleteDepartment(@RequestBody DepLongDTO deleteDTO) {
        departmentService.deleteDepartment(deleteDTO);
    }

    @PostMapping("/search")
    public List<DepartmentDTO> searchDepartments(@RequestParam String name) {
        DepStringDTO searchDTO = new DepStringDTO(name);
        return departmentService.searchDepartments(searchDTO);
    }
}
