package com.SchoProjApp.ProjectWork.Models.ClinicalData;

import com.SchoProjApp.ProjectWork.Models.Admissions.AdmissionState;
import jakarta.persistence.*;


@Entity
@Table
public class ClinicalData {

    @Id
    @SequenceGenerator(
            name = "clinical_data_sequence",
            sequenceName = "clinical_data_sequence",
            allocationSize = 1
    )
    @GeneratedValue(
            strategy = jakarta.persistence.GenerationType.SEQUENCE,
            generator = "clinical_data_sequence"
    )
    private Long id;
    private String clinicalRecord;

    private Long patientId;

    public ClinicalData() {
    }

    public ClinicalData(Long id, String clinicalRecord, Long patientId) {
        this.id = id;
        this.clinicalRecord = clinicalRecord;
        this.patientId = patientId;
    }
    public ClinicalData(String clinicalRecord, Long patientId) {
        this.clinicalRecord = clinicalRecord;
        this.patientId = patientId;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getClinicalRecord() {
        return clinicalRecord;
    }

    public void setClinicalRecord(String clinicalRecord) {
        this.clinicalRecord = clinicalRecord;
    }

    public Long getPatientId() {
        return patientId;
    }
    public void setPatientId(Long patientId) {
        this.patientId = patientId;
    }
}

