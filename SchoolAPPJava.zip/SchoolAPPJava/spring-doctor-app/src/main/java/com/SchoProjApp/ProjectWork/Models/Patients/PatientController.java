package com.SchoProjApp.ProjectWork.Models.Patients;

import com.SchoProjApp.ProjectWork.Models.Patients.dto.PatDelDTO;
import com.SchoProjApp.ProjectWork.Models.Patients.dto.PatSearchDTO;
import com.SchoProjApp.ProjectWork.Models.Patients.dto.PatUpsertDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping(path = "/api/v1/patient")
public class PatientController {
    private final PatientService patientService;
    @Autowired
    public PatientController(PatientService patientService) {
        this.patientService = patientService;
    }

    @GetMapping
    public List<PatUpsertDTO> getPatients() {
        return patientService.getPatients();

    }
    @PostMapping
    public void registerOrUpdatePatient(@RequestBody PatUpsertDTO patientDTO) {
        if (patientDTO.getId() == null) {
            patientService.addNewPatient(patientDTO);
        } else {
            patientService.updatePatient(patientDTO);
        }
    }

    @DeleteMapping
    public void deletePatient(@RequestBody PatDelDTO deleteDTO) {
        patientService.deletePatient(deleteDTO);
    }

    @PostMapping("/search")
    public List<PatUpsertDTO> searchPatients(@RequestBody PatSearchDTO searchDTO) {
        return patientService.searchPatients(searchDTO);
    }





}
