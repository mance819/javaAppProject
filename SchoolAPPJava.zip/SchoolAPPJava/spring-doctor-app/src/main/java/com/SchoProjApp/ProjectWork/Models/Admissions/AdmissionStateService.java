package com.SchoProjApp.ProjectWork.Models.Admissions;

import com.SchoProjApp.ProjectWork.Models.Admissions.dto.AdmissionUpserDTO;
import com.SchoProjApp.ProjectWork.Models.Admissions.dto.LongDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;


@Service
public class AdmissionStateService {

    private final AdmissionStateRepository admissionStateRepository;

    @Autowired
    public AdmissionStateService(AdmissionStateRepository admissionStateRepository) {
        this.admissionStateRepository = admissionStateRepository;
    }

    public List<AdmissionUpserDTO> getAdmissions(){
        return admissionStateRepository.findAll().stream()
                .map(admissionState -> new AdmissionUpserDTO(
                        admissionState.getId(),
                        admissionState.getEnteringDate(),
                        admissionState.getExitingDate(),
                        admissionState.getCause(),
                        admissionState.getReason(),
                        admissionState.isDischarge(),
                        admissionState.getPatientId(),
                        admissionState.getDepartmentId()
                ))
                .collect(Collectors.toList());
    }

    public void addNewAdmissionState(AdmissionUpserDTO admissionStateDTO) {
        AdmissionState admissionState = new AdmissionState(
                admissionStateDTO.getId(),
                admissionStateDTO.getEnteringDate(),
                admissionStateDTO.getExitingDate(),
                admissionStateDTO.getCause(),
                admissionStateDTO.getReason(),
                admissionStateDTO.isDischarge(),
                admissionStateDTO.getPatientId(),
                admissionStateDTO.getDepartmentId()
        );
        admissionStateRepository.findAdmissionStateByPatientIdAndExitingDateIsNull(admissionState.getPatientId())
                .ifPresentOrElse(
                        admissionState1 -> {
                            throw new IllegalStateException("Patient already has an admission state ongoing");
                        },
                        () -> admissionStateRepository.save(admissionState)
                );
    }

    @Transactional
    public void updateAdmissionState(AdmissionUpserDTO admissionStateDTO) {
        Long admissionStateId = admissionStateDTO.getId();
        AdmissionState admissionState = admissionStateRepository.findById(admissionStateId)
                .orElseThrow(() -> new IllegalStateException(
                        "Admission state with id " + admissionStateId + " does not exist"
                ));

        if (admissionStateDTO.getEnteringDate() != null && !admissionStateDTO.getEnteringDate().equals(admissionState.getEnteringDate())) {
            admissionState.setEnteringDate(admissionStateDTO.getEnteringDate());
        }
        if(admissionStateDTO.getExitingDate() != null && !admissionStateDTO.getExitingDate().equals(admissionState.getExitingDate())){
            admissionState.setExitingDate(admissionStateDTO.getExitingDate());
        }
        if(admissionStateDTO.getCause() != null && admissionStateDTO.getCause().length() > 0 && !admissionStateDTO.getCause().equals(admissionState.getCause())){
            admissionState.setCause(admissionStateDTO.getCause());
        }
        if(admissionStateDTO.getReason() != null && admissionStateDTO.getReason().length() > 0 && !admissionStateDTO.getReason().equals(admissionState.getReason())){
            admissionState.setReason(admissionStateDTO.getReason());
        }
        if(admissionStateDTO.isDischarge() != admissionState.isDischarge()){
            admissionState.setDischarge(admissionStateDTO.isDischarge());
        }
        if(admissionStateDTO.getPatientId() != admissionState.getPatientId()){
            admissionState.setPatientId(admissionStateDTO.getPatientId());
        }
        if(admissionStateDTO.getDepartmentId() != admissionState.getDepartmentId()){
            admissionState.setDepartmentId(admissionStateDTO.getDepartmentId());
        }

    }

    public void deleteAdmissionState(Long admissionStateId) {
        boolean exists = admissionStateRepository.existsById(admissionStateId);
        if (!exists) {
            throw new IllegalStateException("Admission state with id " + admissionStateId + " does not exist");
        }
        admissionStateRepository.deleteById(admissionStateId);
    }

    public List<AdmissionUpserDTO> findAdmissionStatebyPatientID(LongDTO admissionStateDTO) {
        Long patientId = admissionStateDTO.getPatientId();
        return admissionStateRepository.findAdmissionStateByPatientId(patientId).stream()
                .map(admissionState -> new AdmissionUpserDTO(
                        admissionState.getId(),
                        admissionState.getEnteringDate(),
                        admissionState.getExitingDate(),
                        admissionState.getCause(),
                        admissionState.getReason(),
                        admissionState.isDischarge(),
                        admissionState.getPatientId(),
                        admissionState.getDepartmentId()
                ))
                .collect(Collectors.toList());
    }


}
