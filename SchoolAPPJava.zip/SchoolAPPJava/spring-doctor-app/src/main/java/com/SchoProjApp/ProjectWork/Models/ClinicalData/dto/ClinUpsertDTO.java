package com.SchoProjApp.ProjectWork.Models.ClinicalData.dto;

public class ClinUpsertDTO {

    private Long id;
    private String clinicalRecord;

    private Long patientId;

    public ClinUpsertDTO(Long id, String clinicalRecord, Long patientId) {
        this.id = id;
        this.clinicalRecord = clinicalRecord;
        this.patientId = patientId;
    }

    public ClinUpsertDTO() {
    }

    public Long getId() {
        return id;
    }

    public String getClinicalRecord() {
        return clinicalRecord;
    }

    public Long getPatientId() {
        return patientId;
    }

    public void setId(long l) {
    }

    public void setClinicalRecord(String clinicalRecord) {
        this.clinicalRecord = clinicalRecord;
    }

    public void setPatientId(Long patientId) {
        this.patientId = patientId;
    }


}
