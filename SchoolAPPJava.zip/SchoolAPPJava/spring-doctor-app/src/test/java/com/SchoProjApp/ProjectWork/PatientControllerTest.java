package com.SchoProjApp.ProjectWork;

import com.SchoProjApp.ProjectWork.Models.Patients.PatientController;
import com.SchoProjApp.ProjectWork.Models.Patients.PatientService;
import com.SchoProjApp.ProjectWork.Models.Patients.dto.PatDelDTO;
import com.SchoProjApp.ProjectWork.Models.Patients.dto.PatSearchDTO;
import com.SchoProjApp.ProjectWork.Models.Patients.dto.PatUpsertDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class PatientControllerTest {

    @Mock
    private PatientService patientService;

    @InjectMocks
    private PatientController patientController;

    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(patientController).build();
    }

    @Test
    void testGetPatients() throws Exception {
        PatUpsertDTO patient1 = new PatUpsertDTO(1L, "John", "Doe", LocalDate.of(1990, 1, 1));
        PatUpsertDTO patient2 = new PatUpsertDTO(2L, "Jane", "Smith", LocalDate.of(1985, 5, 15));

        List<PatUpsertDTO> patients = Arrays.asList(patient1, patient2);

        when(patientService.getPatients()).thenReturn(patients);

        mockMvc.perform(get("/api/v1/patient"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1L))
                .andExpect(jsonPath("$[0].name").value("John"))
                .andExpect(jsonPath("$[0].lastName").value("Doe"))
                .andExpect(jsonPath("$[0].birthDate[0]").value(1990))
                .andExpect(jsonPath("$[0].birthDate[1]").value(1))
                .andExpect(jsonPath("$[0].birthDate[2]").value(1))
                .andExpect(jsonPath("$[1].id").value(2L))
                .andExpect(jsonPath("$[1].name").value("Jane"))
                .andExpect(jsonPath("$[1].lastName").value("Smith"))
                .andExpect(jsonPath("$[1].birthDate[0]").value(1985))
                .andExpect(jsonPath("$[1].birthDate[1]").value(5))
                .andExpect(jsonPath("$[1].birthDate[2]").value(15));

        verify(patientService, times(1)).getPatients();
    }

    @Test
    void testRegisterOrUpdatePatient() throws Exception {
        PatUpsertDTO patientDTO = new PatUpsertDTO(1L, "John", "Doe", LocalDate.of(1990, 1, 1));

        mockMvc.perform(post("/api/v1/patient")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"id\":1,\"name\":\"John\",\"lastName\":\"Doe\",\"birthDate\":[1990,1,1]}"))
                .andExpect(status().isOk());

        verify(patientService, times(1)).updatePatient(any(PatUpsertDTO.class));
    }

    @Test
    void testDeletePatient() throws Exception {
        PatDelDTO deleteDTO = new PatDelDTO(1L);

        mockMvc.perform(delete("/api/v1/patient")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"id\":1}"))
                .andExpect(status().isOk());

        verify(patientService, times(1)).deletePatient(any(PatDelDTO.class));
    }

    @Test
    void testSearchPatients() throws Exception {
        PatUpsertDTO patient1 = new PatUpsertDTO(1L, "John", "Doe", LocalDate.of(1990, 1, 1));
        List<PatUpsertDTO> patients = Arrays.asList(patient1);

        when(patientService.searchPatients(any(PatSearchDTO.class))).thenReturn(patients);

        mockMvc.perform(post("/api/v1/patient/search")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"John\",\"lastName\":\"Doe\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1L))
                .andExpect(jsonPath("$[0].name").value("John"))
                .andExpect(jsonPath("$[0].lastName").value("Doe"))
                .andExpect(jsonPath("$[0].birthDate[0]").value(1990))
                .andExpect(jsonPath("$[0].birthDate[1]").value(1))
                .andExpect(jsonPath("$[0].birthDate[2]").value(1));

        verify(patientService, times(1)).searchPatients(any(PatSearchDTO.class));
    }
}
