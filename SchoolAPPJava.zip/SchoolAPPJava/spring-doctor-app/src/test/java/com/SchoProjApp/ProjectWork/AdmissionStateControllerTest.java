package com.SchoProjApp.ProjectWork;

import com.SchoProjApp.ProjectWork.Models.Admissions.AdmissionStateController;
import com.SchoProjApp.ProjectWork.Models.Admissions.AdmissionStateService;
import com.SchoProjApp.ProjectWork.Models.Admissions.dto.AdmissionUpserDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class AdmissionStateControllerTest {

    @Mock
    private AdmissionStateService admissionStateService;

    @InjectMocks
    private AdmissionStateController admissionStateController;

    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(admissionStateController).build();
    }

    @Test
    void testGetAdmissions() throws Exception {
        AdmissionUpserDTO admission1 = new AdmissionUpserDTO(1L, LocalDate.now(), null, "Cause1", "Reason1", false, 1L, 1L);
        AdmissionUpserDTO admission2 = new AdmissionUpserDTO(2L, LocalDate.now(), null, "Cause2", "Reason2", false, 2L, 2L);

        List<AdmissionUpserDTO> admissions = Arrays.asList(admission1, admission2);

        when(admissionStateService.getAdmissions()).thenReturn(admissions);

        mockMvc.perform(get("/api/v1/admission"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1L))
                .andExpect(jsonPath("$[0].cause").value("Cause1"))
                .andExpect(jsonPath("$[0].reason").value("Reason1"))
                .andExpect(jsonPath("$[0].patientId").value(1L))
                .andExpect(jsonPath("$[0].departmentId").value(1L))
                .andExpect(jsonPath("$[1].id").value(2L))
                .andExpect(jsonPath("$[1].cause").value("Cause2"))
                .andExpect(jsonPath("$[1].reason").value("Reason2"))
                .andExpect(jsonPath("$[1].patientId").value(2L))
                .andExpect(jsonPath("$[1].departmentId").value(2L));

        verify(admissionStateService, times(1)).getAdmissions();
    }

    @Test
    void testRegisterOrUpdateAdmissionState() throws Exception {
        AdmissionUpserDTO admissionDTO = new AdmissionUpserDTO(1L, LocalDate.now(), null, "Cause1", "Reason1", false, 1L, 1L);

        mockMvc.perform(post("/api/v1/admission")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"id\":1,\"enteringDate\":\"2024-06-17T12:00:00\",\"exitingDate\":null,\"cause\":\"Cause1\",\"reason\":\"Reason1\",\"discharge\":false,\"patientId\":1,\"departmentId\":1}"))
                .andExpect(status().isOk());

        verify(admissionStateService, times(1)).updateAdmissionState(any(AdmissionUpserDTO.class));
    }

    @Test
    void testDeleteAdmissionState() throws Exception {
        mockMvc.perform(delete("/api/v1/admission/1")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());

        verify(admissionStateService, times(1)).deleteAdmissionState(1L);
    }
}
